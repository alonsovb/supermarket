package backend.supermercado;

import backend.main.RandomGenerator;

/**
 *
 * @author Alonso
 */
public class Comprador {
    
    private Contenedor contenedor;
    private int tiempoEnFila = 0;
    private Comprador siguiente = null;
    
    public Comprador(int Canastas, int Carritos)
    {
        if (RandomGenerator.getRandom(Canastas + Carritos) < Canastas)
            contenedor = new Canasta();
        else
            contenedor = new Carrito();
    }

    public Contenedor getContenedor() {
        return contenedor;
    }

    public int getTiempoEnFila() {
        return tiempoEnFila;
    }
    
    public void aumentarTiempoEnFila() {
        tiempoEnFila++;
    }

    public Comprador getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Comprador siguiente) {
        this.siguiente = siguiente;
    }
    
}
