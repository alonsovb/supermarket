package backend.supermercado;

import backend.main.RandomGenerator;

/**
 *
 * @author Alonso
 */
public class Controlador {

    private Caja cajas[];
    int tiemposDeEspera[];
    int generadorComprador = 2;
    int totalCarritos = 0;
    int totalCanastas = 0;

    public Controlador(int compradoresPorTurno,
            int Carritos, int Canastas) {
        cajas = new Caja[10];
        tiemposDeEspera = new int[10];
        for (int i = 0; i < cajas.length; i++) {
            if (i > 5) {
                cajas[i] = new CajaExpress(this);
            } else {
                cajas[i] = new Caja(this);
            }
        }
        generadorComprador = compradoresPorTurno;
        totalCanastas = Canastas;
        totalCarritos = Carritos;
    }

    public void siguienteTurno() {
        int generarEsteTurno = generadorComprador;
//                RandomGenerator.getRandom(generadorComprador - 2,
//                generadorComprador + 2);
        for (int i = 0; i < generarEsteTurno; i++) {
            Comprador c = new Comprador(totalCanastas, totalCarritos);
            Caja mejorCaja = getCajas()[0];

            for (int j = 1; j < getCajas().length; j++) {
                if (c.getContenedor().getTotalProductos()
                        < getCajas()[j].getMaxArticulosPersona()
                        && getCajas()[j].getTamañoCola() < mejorCaja.getTamañoCola()) {
                    mejorCaja = getCajas()[j];
                }
            }
            mejorCaja.agregarComprador(c);
        }
        for (int i = 0; i < getCajas().length; i++) {
            getCajas()[i].turno();
        }
    }

    public void agregarTiempoComprador(Comprador comprador, Caja caja) {
        int indice = 0;
        for (indice = 0; indice < getCajas().length; indice++) {
            if (getCajas()[indice] == caja) {
                break;
            }
        }
        tiemposDeEspera[indice] += comprador.getTiempoEnFila();
    }

    public double getTiempoPromedio(int indiceCaja) {
        double te = (double) tiemposDeEspera[indiceCaja];
        double tc = (double) cajas[indiceCaja].getTotalCompradores();
        double r = te / tc;
        return r;
    }

    public int getDinero() {
        int total = 0;
        for (int i = 0; i < getCajas().length; i++) {
            total += getCajas()[i].getDinero();
        }
        return total;
    }

    public int getCompradores() {
        int total = 0;
        for (int i = 0; i < getCajas().length; i++) {
            total += getCajas()[i].getTotalCompradores();
        }
        return total;
    }

    public int getProductos() {
        int total = 0;
        for (int i = 0; i < getCajas().length; i++) {
            total += getCajas()[i].getTotalProductos();
        }
        return total;
    }

    public Caja[] getCajas() {
        return cajas;
    }
}
