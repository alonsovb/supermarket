package backend.main;

import frontend.FrameView;

/**
 *
 * @author Alonso
 */
public class Supermercado {

    public static void main(String args[]) {
        FrameView frame = new FrameView();
        frame.setVisible(true);
    }
}